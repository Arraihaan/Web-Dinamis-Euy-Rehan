<?php
mysqli_connect("localhost","root","") or die ("Gagal terhubung ke database");
mysqli_select_db("login") or die ("Database tidak ditemukan");
?>
