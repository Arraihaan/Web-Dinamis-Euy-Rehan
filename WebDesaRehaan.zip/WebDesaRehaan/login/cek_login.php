<?php
session_start();
include ('../koneksi/koneksi.php');
$email = mysql_real_escape_string($_POST ['email']);
$password = mysql_real_escape_string(md5($_POST ['password']));

if(empty ($email) || empty($password)) {
echo "<script>alert('Email atau Password tidak boleh kosong')</script>";
echo "<meta http-equiv='refresh' content='1 url=login.php'>";
}else {

$sql = $koneksi->query("select * from user where email='$email' and password='$password'");
$data = mysql_fetch_array($sql);

//mengecek jumlah baris untuk hasil query
$cek = mysql_num_rows($sql);

if($cek >0) {
$_SESSION['id_user'] = $data['id_user'];
$_SESSION['status_login'] = "1";
header ('location:../admin/index.php');
exit();
}else {
echo "<script>alert('Anda belum terdaftar')</script>";
echo "<meta http-equiv='refresh' content='1 url=../login/login.php'>";
}
}
?>
