<?php
session_start();
require_once('../koneksi/koneksi.php');
$user = mysql_real_escape_string($_POST ['username']);
$pass = mysql_real_escape_string($_POST ['password']);

if(empty ($user) || empty($pass)) {
echo "<script>alert('Username atau Password tidak boleh kosong')</script>";
echo "<meta http-equiv='refresh' content='1 url=login.php'>";
}else {

	$sql = mysql_query("select * from user where username='$user' and password='$pass'");
	$data = mysql_fetch_array($sql);

//mengecek jumlah baris untuk hasil query
$cek = mysql_num_rows($sql);

	if($cek >0) {
		$_SESSION['id_user'] = $data['id_user'];
		$_SESSION['status_login'] = "1";

header ('location:../admin/tampil_profil.php');
exit();
}else {
echo "<script>alert('Anda belum terdaftar')</script>";
echo "<meta http-equiv='refresh' content='1 url=login.php'>";
}
}
?>
