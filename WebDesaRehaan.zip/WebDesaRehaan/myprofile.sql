-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
-- 
-- Inang: 127.0.0.1
-- Waktu pembuatan: 05 Mei 2018 pada 00.00
-- Versi Server: 5.5.32
-- Versi PHP: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `myprofile`
--
CREATE DATABASE IF NOT EXISTS `myprofile` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `myprofile`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_diri`
--

CREATE TABLE IF NOT EXISTS `data_diri` (
  `Nama` varchar(50) DEFAULT NULL,
  `TTL` varchar(50) DEFAULT NULL,
  `Alamat` varchar(100) DEFAULT NULL,
  `Agama` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_diri`
--

INSERT INTO `data_diri` (`Nama`, `TTL`, `Alamat`, `Agama`) VALUES
('Hermawan Genta Arraihaan', 'Banjarnegara, 18 September 2003', 'Jalan Jati Kusuma No 3, Binangun, Klampok, RT 1/RW 13 ,Banjarnegara, Semarang, Indonesia, Bumi, Bima Sakti', 'Islam');

-- --------------------------------------------------------

--
-- Struktur dari tabel `karya`
--

CREATE TABLE IF NOT EXISTS `karya` (
  `no_karya` int(11) NOT NULL AUTO_INCREMENT,
  `judul_karya` varchar(100) DEFAULT NULL,
  `desc_karya` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`no_karya`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `karya`
--

INSERT INTO `karya` (`no_karya`, `judul_karya`, `desc_karya`) VALUES
(1, 'Kalkulator-Aplikasi Desktop ', 'Membuat kalkulator sendiri? Iya! \r\n kalkulatorn yang saya buat ini adalah kalkulator untuk desktop.Kalkulator ini adalah tugas dari mata pelajaran Pemrograman dekstop. Kalkulator ini dibuat menggunakan aplikasi Visual Basic, namun menggunakan Visual Studio pun bisa. Saya mengerjakan kalkulator ini selama 2 hari.'),
(2, 'Aplikasi Kasir - Aplikasi Desktop', 'Aplikasi kasir ini memiliki beberapa fitur antaranya : menambah barang ke dalam etalase toko,memilih barang lalu menghitung jumlah belanja, menghitung kembalian belanja. Data dalam aplikasi dapat dimasukan kedalam database, database dibuat dengan Access saya membuat aplikasi ini menggunakan visual basic.'),
(3, 'karya inovatif!', '<p>Banyak sekali karya inovatif, <strong>banyak sekali karya inovatif, </strong><em>Banyak karya inovatifff,&nbsp; </em></p>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `no_komen` int(100) NOT NULL AUTO_INCREMENT,
  `Nama_komen` varchar(100) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Komentar` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`no_komen`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `story`
--

CREATE TABLE IF NOT EXISTS `story` (
  `judul_story ` varchar(100) DEFAULT NULL,
  `isi_story` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
GF
--
-- Dumping data untuk tabel `story`
--

INSERT INTO `story` (`judul_story`, `isi_story`) VALUES
('-https://drive.google.com/open?id=1kg3qajIwqRNQpwB40U9_KaV2COrQS7qy \r\n', 'Keren'),

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengalaman`
--

CREATE TABLE IF NOT EXISTS `pengalaman` (
  `judul_pengalaman` varchar(100) DEFAULT NULL,
  `desc_pengalaman` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `story`
--

CREATE TABLE IF NOT EXISTS `story` (
  `no_story` int(11) NOT NULL AUTO_INCREMENT,
  `judul_story` varchar(500) DEFAULT NULL,
  `isi_story` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`no_story`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `story`
--

INSERT INTO `story` (`no_story`, `judul_story`, `isi_story`) VALUES
(1, 'Sejarah Desa', 'Menurut cerita, Desa Klampok adalah suatu wilayah yang berada di sisi timur ibu kota Kadipaten/Kabupaten Wirasaba yang merupakan salah satu Kadipaten / Kabupaten pada jaman Kerajaan Mataram. -'),
(2, 'Keberadaan Desa Klampok ', 'dahulunya merupakan suatu wilayah yang ditempati penduduk secara mengelompok, dan berada di timur sungai serayu, yang membatasi antara wilayah pusat Pemerintahan Kadipaten Wirasaba dan wilayah tersebut ( sekarang Desa Klampok ), sekarang sungai serayu merupakan batas antara Kabupaten Banjarnegara dan Kabupaten Purbalingga, disamping itu Desa Klampok pada jaman dahulu merupakan jalan pintas yang sering dilewati Adipati Warga Utama ( salah satu Adipati Kadipaten Wirasaba ) apabila akan menuju Pusat Pemerintahan Kerajaan Mataram / Kota Yogyakarta. '),
(3, 'Desa Klampok', '<p>Dari sekilas cerita tersebut, Kata Klampok sendiri di ambil dari masyarakat yang mendiami atau hidup dengan cara mengelompok mengelompok / menggerombol sehingga wilayah tersebut di namai Klampok. </p>\r\n'),
(4, 'Klampok - Purwareja Klampok', '<p>Klampok Is Ngledepok.</p>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('admin1', 'passadmin1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
