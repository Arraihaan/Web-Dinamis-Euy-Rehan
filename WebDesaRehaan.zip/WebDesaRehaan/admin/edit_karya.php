<?php
	include('header_admin.php');
	include('sidebar_admin.php');

?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>

            <small>Profile Saya</small>
          </h1>
          <ol class="breadcrumb">
            <li class="active">admin</li>
          </ol>
        </section>
				<!-- Main content -->
				<section class="content">
					<script type="text/javascript" src="../ckeditor/ckeditor.js">
					</script>
					<div class="col-md-12">
						<?php
						include ('../koneksi/koneksi.php');
						$test=mysql_query("SELECT * FROM karya");
						while($data=mysql_fetch_array($test)) {
						?>
												<div class="box box-info">
													<div class="box-header">
														<h3 class="box-title">Karya &nbsp;<small>edit</small></h3>
														<!-- tools box -->
														<div class="pull-right box-tools">
															<button title="Collapse" class="btn btn-info btn-sm" data-toggle="tooltip" data-widget="collapse"><i class="fa fa-minus"></i></button>
													</div><!-- /. tools -->
													</div><!-- /.box-header -->
													<div class="box-body pad">
														<form action="update_edit.php" method="POST">
															<div class="form-group">
																<input type="hidden" name="no" value="<?php echo $no; ?>" />
																<table>Judul</table> <input type="text" class="form-control" name="judul_karya" value="<?php echo $out['judul_karya']; ?>">
															</div><hr>
															<div class="form-group">
																<table>Deskripsi</table> <textarea class="form-control ckeditor" name="desc_karya" class="form-control" rows="18"><?php echo $out['desc_karya']; ?></textarea>
															</div>
															<input type="submit" value="Update" class="btn btn-info"><br>
														</form>
													</div>
												</div><!-- /.box -->
												<?php
												};
												mysql_close();
												?>
											</div>
				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

<?php
	include('footer_admin.php');
?>
