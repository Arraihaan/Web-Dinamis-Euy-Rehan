<?php
include ('../koneksi/koneksi.php');
$no=$_GET['no'];
$hapus=mysql_query("DELETE FROM story WHERE no_story='$no'");
if(hapus) {
		header("location:tampil_profil.php");
}
?>
