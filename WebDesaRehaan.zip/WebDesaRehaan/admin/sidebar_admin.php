
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="">
            </div>
            <div class="pull-left info">
              <p>Hermawan Genta Arraihaan</p>
            </div>
            <hr>
          </div>

          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">


            <li class="header">Navigasi Utama</li>
            <li class="active treeview">

                          <a href="#">
                            <i class="fa fa-user"></i> <span>Profile</span>
                          </a>
                          <ul class="treeview-menu">
                            <li><a href="tampil_profil.php"></i>Tampil Profile</a></li>

                          </ul>
                        </li>
                      <li class="active treeview">
                        <a href="#">
                          <i class="fa fa-image"></i> <span>Galeri</span>
                        </a>
                        <ul class="treeview-menu">
                          <li><a href="tampil_karya.php"></i>Tampil Karya</a></li>
                        </ul>
                      </li>
        </section>
        <!-- /.sidebar -->
      </aside>
