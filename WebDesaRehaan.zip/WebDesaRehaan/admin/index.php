<?php
	include('header_admin.php');
	include('sidebar_admin.php');

?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>

            <small>Profile Saya</small>
          </h1>
          <ol class="breadcrumb">
            <li class="active">Home</li>
          </ol>
        </section>

				<!-- Main content -->
				<section class="content">
					<div class="callout callout-info">
	              <h4>Hai,Ohayou?</h4>
	              <p> Anda sekarang Admin/Adm00n </p>
	            </div>
							<!-- Widget: user widget style 1 -->
							<div class="box box-widget widget-user">
								<!-- Add the bg color to the header using any of the bg-* classes -->
								<div class="widget-user-header bg-aqua-active">
									<h5 class="widget-user-username">Hermawan Genta Arraihaan</h5>
									<h5 class="widget-user-desc">Software Engineering 2</h5>
								</div>
								<div class="widget-user-image">
									<img class="img-circle" alt="User Avatar" src="../img/pict.jpg">
								</div>
								<div class="box-footer">
									<div class="row">
										<div class="col-sm-4 border-right">
											<div class="description-block">
												<h5 class="description-header">WhatsApp</h5>
												<span class="description-text">+62877-1509-2988</span>
											</div><!-- /.description-block -->
										</div><!-- /.col -->
										<div class="col-sm-4 border-right">
											<div class="description-block">
												<h5 class="description-header">Gmail</h5>
												<span>hermawanhan12@gmail.com</span>
											</div><!-- /.description-block -->
										</div><!-- /.col -->
										<div class="col-sm-4">
											<div class="description-block">
												<h5 class="description-header">Instagram</h5>
												<span>@hanssvouz_</span>
											</div><!-- /.description-block -->
										</div><!-- /.col -->
									</div><!-- /.row -->
								</div>
							</div><!-- /.widget-user -->
				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

<?php
	include('footer_admin.php');
?>
