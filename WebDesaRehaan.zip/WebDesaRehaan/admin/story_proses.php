<?php

include('../koneksi/koneksi.php');

$judul=$_POST['judul_story'];
$isi=$_POST['isi_story'];
$test=mysql_query("INSERT INTO story (judul_story,isi_story) VALUES ('$judul','$isi')");
if($test) {
	header("location:tampil_profil.php");
}else {
	echo "GAGAL";
	}
?>
