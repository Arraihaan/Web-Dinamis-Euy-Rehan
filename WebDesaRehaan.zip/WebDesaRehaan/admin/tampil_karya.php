<?php
	include('header_admin.php');
	include('sidebar_admin.php');

?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>

            <small>Profile Saya</small>
          </h1>
          <ol class="breadcrumb">
            <li class="active">admin</li>
          </ol>
        </section>

				<!-- Main content -->
				<section class="content">
					<div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Galeri Karya</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="table-responsive">
                    <table class="table no-margin">
                      <thead>
                        <tr>
                          <th>Judul Karya</th>
                          <th class="pull-right">Aksi</th>
                        </tr>
                      </thead>
											<?php
											include ('../koneksi/koneksi.php');
											$test=mysql_query("SELECT * FROM karya");
											while($data=mysql_fetch_array($test)) {
											?>
                      <tbody>
                        <tr>
                          <td><?php echo $data['judul_karya'];?></td>
                          <td><a href="hapus_karya.php?no=<?php echo $data['no_karya']; ?>"><i class="btn btn-danger pull-right"><i class="fa fa-remove"></i></i></a></td>
                        </tr>
												<?php
												};
												mysql_close();
												?>

                      </tbody>
                    </table>
                  </div><!-- /.table-responsive -->
              </div>
							<hr>
							<td><a href="input_karya.php"><i class="btn btn-primary pull-right">INPUT</i></a>
				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

<?php
	include('footer_admin.php');
?>
