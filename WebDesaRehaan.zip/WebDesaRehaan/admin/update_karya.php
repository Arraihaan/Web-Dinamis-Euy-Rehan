<?php
include ('../koneksi/koneksi.php');
$no=$_POST['no'];
$judul=$_POST['judul_karya'];
$isi=$_POST['desc_karya'];
$edit= mysql_query("UPDATE karya SET judul_karya='$judul',desc_karya='$isi' WHERE no_karya='$no'");
if($edit) {
	header("location:tampil_profil.php");

}else {
	echo "GAGAL";
	}
?>
