<?php

include('../koneksi/koneksi.php');

$judul=$_POST['judul_karya'];
$isi=$_POST['desc_karya'];
$test=mysql_query("INSERT INTO karya (judul_karya,desc_karya) VALUES ('$judul','$isi')");
if($test) {
	header("location:tampil_karya.php");
}else {
	echo "GAGAL";
	}
?>
