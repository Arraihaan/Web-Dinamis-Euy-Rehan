<?php
	include('tema/header.php');
	include('tema/sidebar.php');

?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>

            <h2>Cerita Saya</h2>
          </h1>
          <ol class="breadcrumb">
            <li class="active">Profiles Saya</li>
          </ol>
        </section>

				<!-- Main content -->
				<section class="content">
					<!-- Small boxes (Stat box) -->
					<div class="row">
						<div class="col-xs-12">

			<?php
			include ('koneksi/koneksi.php');
			$test=mysql_query("SELECT * FROM story");
			while($data=mysql_fetch_array($test)) {
			?>
			<div class="box">
			<div class="box-header with-border">
			<h4><?php echo $data['judul_story'];?></h4><br>
			</div>
			<div class="box-body">
			<?php echo substr( $data ['isi_story'],0,100);?> . . .<br>
			</div>
			<div class="box-footer">
			<a href="tampil_story.php?no=<?php echo $data['no_story']; ?>"> Baca Selengkapnya</a><hr>
			</div>
			</div>
			<?php
			};
			mysql_close();
			?>

							</div><!-- /.box -->
					</div><!-- /.row (main row) -->

				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

<?php
	include('tema/footer.php');
?>
