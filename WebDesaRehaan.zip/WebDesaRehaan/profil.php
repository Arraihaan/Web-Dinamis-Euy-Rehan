<?php
	include('tema/header.php');
	include('tema/sidebar.php');

?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>

            <h2>Tentang Saya?</h2>
          </h1>
          <ol class="breadcrumb">
            <li class="active">Profile Saya</li>
          </ol>
        </section>

				<!-- Main content -->
				<section class="content">
				              <!-- Profile Image -->

              <div class="box box-primary">
                <div class="box-body box-profile">
                  <img class="profile-user-img img-responsive img-circle" alt="User profile picture" src="img/pict.jpg">
                  <h3 class="profile-username text-center">Data Diri</h3>
                  <p class="text-muted text-center">Hermawan Genta Arraihaan</p>
									<?php
									include ('koneksi/koneksi.php');
									$test=mysql_query("SELECT * FROM data_diri");
									while($data=mysql_fetch_array($test)) {
									?>
                  <ul class="list-group list-group-unbordered">
                    <li class="list-group-item">
                      <b>Nama </b><a class="pull-right"><?php echo $data['Nama'];?></a>
                    </li>
                    <li class="list-group-item">
                      <b>Tempat,Tanggal Lahir</b> <a class="pull-right"><?php echo $data['TTL'];?></a>
                    </li>
                    <li class="list-group-item">
                      <b>Alamat </b> <a class="pull-right"><?php echo $data['Alamat'];?></a>
                    </li>
										<li class="list-group-item">
                      <b>Agama </b> <a class="pull-right"><?php echo $data['Agama'];?></a>
                    </li>
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
						<?php
						};
						mysql_close();
						?>
              <!-- About Me Box -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">About Me</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <strong><i class="fa fa-book margin-r-5"></i>Riwayat Pendidikan</strong>
                  <p class="text-muted">
                    -TK Pertiwi	Purwareja Klampok 2007 - 2008</br>
										-SD N 1 Krandegan 2008 - 2014</br>
										-SMP N 1 Purwareja Klampok 2014 - 2017</br>
										-SMK N 1 Bawang 2017 sampai saat ini</br>
                  </p>

                  <hr>

                  <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
                  <p class="text-muted">Banjarnegara,Jawa Tengah</p>

                  <hr>

                  <strong><i class="fa fa-users margin-r-5"></i>Pengalaman Organisasi</strong>
                  <p>
                    <span class="label label-primary">Multimedia SMKN 1 Bawang</span>
                    <span class="label label-warning">Mading & Jurnalistik SMKN 1 Bawang</span>
                    <span class="label label-danger">OSIS & MPK SMKN 1 Bawang</span>
                  </p>

                  <hr>

                  <strong><i class="fa fa-file-text-o margin-r-5"></i> Notes</strong>
                  <p>Berjalan pada satu jalur, bukan di jalur</p>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
				</section><!-- /.content -->
			</div><!-- /.content-wrapper -->

<?php
	include('tema/footer.php');
?>
