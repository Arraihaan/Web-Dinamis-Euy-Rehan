<?php

include('koneksi/koneksi.php');

$nama=$_POST['nama_komen'];
$email=$_POST['email'];
$isi=$_POST['komentar']
$cek=mysql_query("INSERT INTO komentar (Nama_komen,Email,Komentar) VALUES ('$nama','$email','$isi')");
if($cek) {
	header("location:tampil_karya.php");
}else {
	echo "GAGAL";
	}
?>
