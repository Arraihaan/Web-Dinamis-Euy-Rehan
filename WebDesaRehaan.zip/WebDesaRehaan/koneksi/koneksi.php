<?php
	$server = "localhost";
	$user = "root";
	$pass = "";
	$db = "myprofil";
	$connect = mysql_connect($server, $user, $pass);
	mysql_select_db($db, $connect);
?>
